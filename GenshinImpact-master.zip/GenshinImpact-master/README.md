# GenshinImpact
Hey traveler, this repo is meant for Intel Integrated GPU owners which would like to play Genshin Impact but are unable / hindered trying to due to the crashes and freezes that occur on Intel Integrated GPU's.

This repo contains a script that aims to apply most of the community found fixes in an easy and customizable way so the non-techies under us can play this game as well without having to worry about touching the wrong setting/option and potentially screwing up their system.

Ad astra abyssoque! traveler.

# Download the script
You can download the script here: https://github.com/Lyceris-chan/GenshinImpact/archive/master.zip

# Notes

It might be necessary to place the script on your desktop, since some people had issues when the script was run from a directory with spaces in it.

# Errors / Issues

While I made sure to test the script thoroughly on my own and with the help of other players in the Discord server there is always a possibility of me missing a small detail,

In that case, I would like to ask you to join our discord server over at https://discord.gg/FS6cF5HAbN and to let me know what issue you experience or just to talk with our fellow intel users.


# Credits 
- u/loltheybannedshaman for his work on the reddit thread
- Mathieu Squidward for his help with the issues i had
- ElectroAegis for being an amazing tester
- Rob van der Woude for his bat code checker
- The people over at stackoverflow
- shirooo39 over at GitHub for his work on the custom resolution part of this script
